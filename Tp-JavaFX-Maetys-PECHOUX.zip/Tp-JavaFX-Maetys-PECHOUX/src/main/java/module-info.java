module org.example.tpjavafxmaetyspechoux {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.tpjavafxmaetyspechoux to javafx.fxml;
    exports org.example.tpjavafxmaetyspechoux;
}