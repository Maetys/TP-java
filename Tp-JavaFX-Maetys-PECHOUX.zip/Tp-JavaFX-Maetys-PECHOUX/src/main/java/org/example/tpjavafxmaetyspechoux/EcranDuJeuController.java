package org.example.tpjavafxmaetyspechoux;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.Random;

/**
 * Contrôleur de la vue EcranDuJeu.fxml.
 */
public class EcranDuJeuController {
    /** Tableau des longueurs des bateaux du joueur. */
    public static int[] longueurBateaux = {2, 3, 3, 4, 5};

    /** Tableau des longueurs des bateaux de l'ordinateur. */
    public static int[] longueurBateauxOrdi = {1, 2, 3, 4, 5};

    /** Grille des bateaux du joueur. */
    public static int[][] grilleBateauxJoueur = new int[10][10];

    /** Grille des bateaux de l'ordinateur. */
    public static int[][] grilleBateauxOrdi = new int[10][10];

    /** Noms des bateaux. */
    public static String[] nomBateaux = {"torpilleur", "sous-marin", "contre-torpilleur", "croiseur", "porte-avions"};

    /** Compteur des bateaux du joueur. */
    int compteurBateauxUtilisateur, compteurBateauxOrdinateur;

    /** Chargement des images. */
    Image imageTorpilleur = new Image("/image/torpilleur.png");
    Image imageSousMarin = new Image("/image/sousMarin.png");
    Image imageContreTorpilleur = new Image("/image/contreTorpilleur.png");
    Image imageCroiseur = new Image("/image/croiseur.png");
    Image imagePorteAvions = new Image("/image/porteAvions.png");

    boolean torpilleurBool, sousMarinBool, contreTorpilleurBool, croiseurBool, porteAvionsBool, tricheActivee, partieTerminee;
    private static Button button;

    @FXML
    private GridPane gridPaneAdversaire;

    @FXML
    private GridPane gridPaneJoueur;

    @FXML
    private Text afficherTextTir;

    /**
     * Méthode d'initialisation du contrôleur.
     */
    @FXML
    public void initialize() {
        compteurBateauxOrdinateur = 0;
        compteurBateauxUtilisateur = 0;
        partieTerminee = false;

        afficherBateau(PlacementBateauxController.envoyerGrillePlacement);

        tricheActivee = MenuController.triche;

        afficherBateau(grilleBateauxJoueur, gridPaneJoueur);

        remplirGrilleOrdinateur();

        contreTorpilleurBool = false;
        croiseurBool = false;
        sousMarinBool = false;
        torpilleurBool = false;
        porteAvionsBool = false;

        afficherBateau(grilleBateauxOrdi, gridPaneAdversaire);

        afficherCacherImageEnemi();
    }

    /**
     * Méthode appelée lorsque l'utilisateur souhaite désactiver la triche.
     */
    @FXML
    void tricheEstActivee() {
        tricheActivee = true;
        afficherCacherImageEnemi();
    }

    /**
     * Méthode appelée lorsque l'utilisateur souhaite activer la triche.
     */
    @FXML
    void tricheEstDesactivee() {
        tricheActivee = false;
        afficherCacherImageEnemi();
    }

    /**
     * Méthode appelée lorsqu'un bateau du joueur est tiré.
     * @param event Événement de clic sur le bouton de tir.
     * Appel la méthode tirUtilisateur et tirOrdinateur.
     */
    @FXML
    void tireBateauJoueur(ActionEvent event) {
        if (!partieTerminee){
            button = (Button) event.getSource();

            int ligne = GridPane.getRowIndex(button);
            int colonne = GridPane.getColumnIndex(button);

            tirUtilisateur(grilleBateauxOrdi, ligne - 1, colonne - 1);

            tirOrdinateur();
        }
    }

    /**
     * Gère le tir effectué par le joueur sur la grille de l'ordinateur.
     * Affiche le résultat du tir et met à jour l'état des bateaux touchés.
     * @param grille Grille des bateaux de l'ordinateur.
     * @param ligne Ligne où le tir est effectué.
     * @param colonne Colonne où le tir est effectué.
     */
    public void tirUtilisateur(int[][] grille, int ligne, int colonne) {
        int numeroBateau;
        char lettre = (char) (colonne + 'A');

        if (grille[ligne][colonne] == 0) {
            button.setStyle("-fx-background-color: #008000;");
            button.setDisable(true);
            afficherTextTir.setText("Tir raté en " + (ligne + 1) + " et " + lettre);
        }

        if (grille[ligne][colonne] != 0 && grille[ligne][colonne] != 6) {
            numeroBateau = grille[ligne][colonne];
            grille[ligne][colonne] = 6;

            button.setStyle("-fx-background-color: #ff0000;");
            button.setDisable(true);

            if (couler(grille, numeroBateau)) {
                afficherTextTir.setText("Le bateau " + nomBateaux[numeroBateau - 1] + " est coulé");

                compteurBateauxUtilisateur++;

                if(compteurBateauxUtilisateur >= 5){
                    afficherTextTir.setText("Vous avez gagné félicitation !");
                    partieTerminee = true;
                }
            } else{
                afficherTextTir.setText("Vous avez touché un bateau.");
            }
        }
    }

    /**
     * Gère le tir effectué par l'ordinateur sur la grille du joueur.
     * Affiche le résultat du tir et met à jour l'état des bateaux touchés.
     */
    public void tirOrdinateur(){
        int ligne, colonne;
        Random random;

        random = new Random();
        ligne = random.nextInt(10);

        random = new Random();
        colonne = random.nextInt(10);

        mouvementOrdi(ligne, colonne);
    }

    /**
     * Effectue le mouvement de l'ordinateur en tirant aléatoirement sur la grille du joueur.
     * Affiche le résultat du tir et met à jour l'état des bateaux touchés.
     * @param ligne Ligne où le tir est effectué.
     * @param colonne Colonne où le tir est effectué.
     */
    public void mouvementOrdi(int ligne, int colonne){
        int numeroBateau;

        button = new Button();

        for (Node node : gridPaneJoueur.getChildren()) {
            if (GridPane.getRowIndex(node) != null && GridPane.getRowIndex(node) == (ligne + 1) && GridPane.getColumnIndex(node)
                    != null && GridPane.getColumnIndex(node) == (colonne + 1) && node instanceof Button) {
                button = (Button) node;
            }
        }

        if (grilleBateauxJoueur[ligne][colonne] == 0) {
            button.setStyle("-fx-background-color: #008000;");
            button.setDisable(true);
        }

        if (grilleBateauxJoueur[ligne][colonne] != 0 && grilleBateauxJoueur[ligne][colonne] != 6){
            numeroBateau = grilleBateauxJoueur[ligne][colonne];
            grilleBateauxJoueur[ligne][colonne] = 6;

            button.setStyle("-fx-background-color: #ff0000;");
            button.setDisable(true);

            if (couler(grilleBateauxJoueur, numeroBateau)){
                afficherTextTir.setText("L'adversaire à coulé un de vos bateaux");
                compteurBateauxOrdinateur++;

                if(compteurBateauxUtilisateur >= 5){
                    afficherTextTir.setText("Vous avez perdu réessayez !");
                    partieTerminee = true;
                }
            }
        }
    }

    /**
     * Vérifie si un bateau est coulé dans la grille donnée.
     * @param grille Grille des bateaux.
     * @param numeroBateau Numéro du bateau à vérifier.
     * @return true si le bateau est coulé, sinon false.
     */
    public static boolean couler(int[][] grille, int numeroBateau) {

        for (int x = 0; x <= 9; x++) {
            for (int i = 0; i <= 9; i++) {
                if (grille[x][i] == numeroBateau) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Remplit la grille des bateaux de l'ordinateur.
     */
    public static void remplirGrilleOrdinateur() {
        int ligne, colonne, direction, nombreDeBateaux = 0;
        int bateau;
        Random random;

        while (nombreDeBateaux != 5) {

            do {
                do {
                    random = new Random();
                    bateau = random.nextInt(5);
                } while (longueurBateauxOrdi[bateau] == 0);

                random = new Random();
                ligne = random.nextInt(10) + 1;

                random = new Random();
                colonne = random.nextInt(10) + 1;

                random = new Random();
                direction = random.nextInt(2) + 1;

                if (positionValide(grilleBateauxOrdi, ligne, colonne, direction, longueurBateaux[bateau])) {
                    placerBateau(ligne, colonne, direction, longueurBateaux[bateau], longueurBateauxOrdi[bateau]);
                    longueurBateauxOrdi[bateau] = 0;
                }

            } while (longueurBateauxOrdi[bateau] != 0);

            nombreDeBateaux++;
        }
    }

    /**
     * Vérifie si la position d'un bateau est valide dans la grille.
     * @param grille Grille des bateaux.
     * @param ligne Ligne de départ du bateau.
     * @param colonne Colonne de départ du bateau.
     * @param direction Direction du bateau (1 pour horizontal, 2 pour vertical).
     * @param longueur Longueur du bateau.
     * @return true si la position est valide, sinon false.
     */
    public static boolean positionValide(int[][] grille, int ligne, int colonne, int direction, int longueur) {

        if (direction == 2) {
            if (ligne + longueur <= 10) {
                for (int i = 0; i < longueur; i++) {
                    if (grille[(ligne - 1) + i][colonne - 1] != 0) {
                        return false;
                    }
                }
            } else {
                return false;
            }
        } else {
            if (colonne + longueur <= 10) {
                for (int i = 0; i < longueur; i++) {
                    if (grille[ligne - 1][(colonne - 1) + i] != 0) {
                        return false;
                    }
                }
            } else {
                return false;
            }
        }

        return true;
    }

    /**
     * Place un bateau dans la grille.
     * @param ligne Ligne de départ du bateau.
     * @param colonne Colonne de départ du bateau.
     * @param direction Direction du bateau (1 pour horizontal, 2 pour vertical).
     * @param longueur Longueur du bateau.
     * @param numeroAPlacer Numéro du bateau à placer.
     */
    public static void placerBateau(int ligne, int colonne, int direction, int longueur, int numeroAPlacer){
        for (int i = 0 ; i < longueur ; i++){
            if (direction == 2){
                grilleBateauxOrdi[(ligne - 1) + i][colonne - 1] = numeroAPlacer;
            }
            else{
                grilleBateauxOrdi[ligne - 1][(colonne - 1) + i] = numeroAPlacer;
            }
        }
    }

    /**
     * Affiche les images des bateaux dans la grille.
     * @param tab Grille des bateaux.
     * @param gridpane Grille où afficher les images.
     */
    public void afficherBateau(int[][] tab, GridPane gridpane) {
        ImageView imageViewTemp;

        for (int i = 0; i < 10; i++) {

            for (int x = 0; x < 10; x++) {

                if (x < 9 && tab[i][x] == tab[i][x + 1] && tab[i][x] != 0) {

                    switch (tab[i][x]) {
                        case 5:
                            if (!porteAvionsBool) {
                                porteAvionsBool = true;
                                imageViewTemp = new ImageView(imagePorteAvions);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(150);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        case 4:
                            if (!croiseurBool) {
                                croiseurBool = true;
                                imageViewTemp = new ImageView(imageCroiseur);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(120);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        case 3:
                            if (!contreTorpilleurBool) {
                                contreTorpilleurBool = true;
                                imageViewTemp = new ImageView(imageContreTorpilleur);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(85);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        case 2:
                            if (!sousMarinBool) {
                                sousMarinBool = true;
                                imageViewTemp = new ImageView(imageSousMarin);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(85);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        case 1:
                            if (!torpilleurBool) {
                                torpilleurBool = true;
                                imageViewTemp = new ImageView(imageTorpilleur);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(60);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        // Ajoutez des cas pour d'autres types de bateaux si nécessaire
                        default:
                            // Code pour d'autres types de bateaux
                            break;
                    }
                } else {

                    switch (tab[i][x]) {
                        case 5:
                            if (!porteAvionsBool) {
                                porteAvionsBool = true;
                                imageViewTemp = new ImageView(imagePorteAvions);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(115);
                                imageViewTemp.setRotate(90);
                                imageViewTemp.setTranslateX(imageViewTemp.getTranslateX() - 44);
                                imageViewTemp.setTranslateY(imageViewTemp.getTranslateY() + 44);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        case 4:
                            if (!croiseurBool) {
                                croiseurBool = true;
                                imageViewTemp = new ImageView(imageCroiseur);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(92);
                                imageViewTemp.setRotate(90);
                                imageViewTemp.setTranslateX(imageViewTemp.getTranslateX() - 32);
                                imageViewTemp.setTranslateY(imageViewTemp.getTranslateY() + 32);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        case 3:
                            if (!contreTorpilleurBool) {
                                contreTorpilleurBool = true;
                                imageViewTemp = new ImageView(imageContreTorpilleur);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(69);
                                imageViewTemp.setRotate(90);
                                imageViewTemp.setTranslateX(imageViewTemp.getTranslateX() - 22);
                                imageViewTemp.setTranslateY(imageViewTemp.getTranslateY() + 22);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        case 2:
                            if (!sousMarinBool) {
                                sousMarinBool = true;
                                imageViewTemp = new ImageView(imageSousMarin);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(69);
                                imageViewTemp.setRotate(90);
                                imageViewTemp.setTranslateX(imageViewTemp.getTranslateX() - 20);
                                imageViewTemp.setTranslateY(imageViewTemp.getTranslateY() + 24);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        case 1:
                            if (!torpilleurBool) {
                                torpilleurBool = true;
                                imageViewTemp = new ImageView(imageTorpilleur);
                                imageViewTemp.setFitHeight(20);
                                imageViewTemp.setFitWidth(46);
                                imageViewTemp.setRotate(90);
                                imageViewTemp.setTranslateX(imageViewTemp.getTranslateX() - 12);
                                imageViewTemp.setTranslateY(imageViewTemp.getTranslateY() + 15);
                                gridpane.add(imageViewTemp, x + 1, i + 1);
                            }
                            break;
                        // Ajoutez des cas pour d'autres types de bateaux si nécessaire
                        default:
                            // Code pour d'autres types de bateaux
                            break;
                    }
                }
            }
        }
    }

    /**
     * Affiche ou cache les images des bateaux de l'ordinateur selon l'état de la triche.
     */
    public void afficherCacherImageEnemi(){
        if(tricheActivee){
            for (Node node : gridPaneAdversaire.getChildren()) {
                if (node instanceof ImageView imageView) {
                    // Vérifie si le nœud est un ImageView
                    imageView.setVisible(true); // Affiche l'ImageView.
                }
            }
        }
        else{
            for (Node node : gridPaneAdversaire.getChildren()) {
                if (node instanceof ImageView imageView) {
                    // Vérifie si le nœud est un ImageView
                    imageView.setVisible(false); // Cache l'ImageView.
                }
            }
        }
    }

    /**
     * Copie la grille des bateaux envoyée dans la grille des bateaux du joueur.
     * @param tab Grille des bateaux à copier.
     */
    void afficherBateau(int[][] tab){
        for (int i = 0; i < 10; i++) {
            System.arraycopy(tab[i], 0, grilleBateauxJoueur[i], 0, 10);
        }
    }

    /**
     * Méthode appelée pour quitter une partie et revenir au menu principal.
     * @throws IOException Exception en cas de problème lors du chargement de la vue du menu principal.
     */
    @FXML
    private void quitterUnePartie() throws IOException {
        HelloApplication.changerScene("Menu");
    }

    /**
     * Méthode appelée pour revenir à l'écran de placement des bateaux.
     * @throws IOException Exception en cas de problème lors du chargement de la vue du menu principal.
     */
    @FXML
    private void recommencerUnePartie() throws IOException{
        HelloApplication.changerScene("PlacementBateaux");
    }
}
