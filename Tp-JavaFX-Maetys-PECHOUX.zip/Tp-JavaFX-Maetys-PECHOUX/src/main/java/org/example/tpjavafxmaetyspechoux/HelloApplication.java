/**
 * @author : Maétys PECHOUX
 * @date : 21-04-2024
 * @version : 1.2
 * But : Donner aspect graphique à votre jeu de bataille navale. Le joueur devra sélectionnez l’une des options
 * affichées dans un menu, pour ensuite pouvoir commencer une partie de bataille navale contre l’ordinateur. Les
 * options lui permettront de tricher ou de jouer à la régulière. Le joueur devra ensuite disposer tous ses bateaux
 * sur la grille, à l’aide de la souris, avant de pouvoir démarrer la partie.
 */

package org.example.tpjavafxmaetyspechoux;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Classe principale de l'application Bataille Navale.
 */
public class HelloApplication extends Application {

    /** Référence vers la scène principale de l'application. */
    static Stage stage;

    /** Référence vers la scène actuellement affichée. */
    static Scene scene;

    /**
     * Méthode principale de l'application.
     * @param stage La fenêtre principale de l'application.
     * @throws IOException Si une erreur survient lors du chargement de la vue Menu.fxml.
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Menu.fxml"));
        HelloApplication.stage = stage;
        Scene scene = new Scene(fxmlLoader.load(), 1000, 650);
        stage.setResizable(false);
        stage.setTitle("Bataille Navale");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Méthode permettant de changer la scène affichée.
     * @param sceneACharger Le nom de la vue FXML à charger.
     * @throws IOException Si une erreur survient lors du chargement de la nouvelle scène.
     */
    public static void changerScene(String sceneACharger) throws IOException {

        // Cacher la scène actuelle avant de charger la nouvelle
        if (scene != null && scene.getWindow() != null) {
            scene.getWindow().hide();
        }

        // Charger la nouvelle scène depuis le fichier FXML
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(sceneACharger + ".fxml"));
        scene = new Scene(fxmlLoader.load(), 1000, 650);
        stage.setResizable(false);
        stage.setTitle("Bataille Navale");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Point d'entrée de l'application.
     */
    public static void main(String[] args) {
        launch();
    }
}