package org.example.tpjavafxmaetyspechoux;

import javafx.fxml.FXML;
import javafx.application.Platform;

import java.io.IOException;

/**
 * Contrôleur de la vue Menu.fxml.
 */
public class MenuController {

    /** Indique si la triche est activée. */
    public static boolean triche;

    /**
     * Méthode d'initialisation du contrôleur.
     * Initialise la variable de triche à false.
     */
    public void initialize() {
        triche = false;
    }

    /**
     * Méthode appelée lors du clic sur le bouton pour activer la triche.
     * @throws IOException Si une erreur survient lors du changement de scène vers PlacementBateaux.
     */
    @FXML
    public void activerTriche() throws IOException {
        // Appel de la méthode de changement de scène et activation de la triche
        HelloApplication.changerScene("PlacementBateaux");
        triche = true;
    }

    /**
     * Méthode appelée lors du clic sur le bouton pour afficher la vue PlacementBateaux.
     * @throws IOException Si une erreur survient lors du changement de scène vers PlacementBateaux.
     */
    @FXML
    private void afficherPlacementBateaux() throws IOException {
        // Appel de la méthode de changement de scène pour afficher la vue PlacementBateaux
        HelloApplication.changerScene("PlacementBateaux");
    }

    /**
     * Méthode appelée lors du clic sur le bouton pour quitter le jeu.
     */
    @FXML
    void quitterJeu() {
        // Ferme l'application
        Platform.exit();
    }
}
