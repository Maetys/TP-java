package org.example.tpjavafxmaetyspechoux;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.transform.Rotate;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

import java.io.IOException;

/**
 * Contrôleur de la vue PlacementBateaux.fxml.
 */
public class PlacementBateauxController {
    /** Tableau des longueurs des bateaux. */
    public static int [] longueurBateaux = {2,3,3,4,5};

    /** Grille de placement des bateaux. */
    public static int [][] grillePlacement = new int [10][10];

    /** Grille de placement des bateaux à envoyer. */
    public static int [][] envoyerGrillePlacement = new int [10][10];

    int choixBateau; /** Choix du bateau actuel. */

    int compteurBateaux = 0; /** Compteur de bateaux placés. */

    boolean bateauHorizontale = true; /** Indique si le bateau est horizontal. */

    private final Rotate rotation = new Rotate(); /** Transformation de rotation. */

    @FXML
    private Text afficherText;

    @FXML
    private GridPane gridPane;

    @FXML
    private ImageView imageView;

    MenuItem menuItem;


    /** Chargement des images. */
    Image imageTorpilleur = new Image("/image/torpilleur.png");
    Image imageSousMarin = new Image("/image/sousMarin.png");
    Image imageContreTorpilleur = new Image("/image/contreTorpilleur.png");
    Image imageCroiseur = new Image("/image/croiseur.png");
    Image imagePorteAvions = new Image("/image/porteAvions.png");

    @FXML
    private MenuItem menuItemTorpilleur;

    /**
     * Méthode d'initialisation du contrôleur.
     */
    @FXML
    public void initialize() {
        bateauHorizontale = true;

        compteurBateaux = 0;

        // Initialisation des grilles de placement
        for (int i = 0 ; i < 10 ; i++){
            for (int x = 0 ; x < 10 ; x++){
                grillePlacement[i][x] = 0;
                envoyerGrillePlacement[i][x] = 0;
            }
        }

        choixBateau = 1;
        imageView.setImage(imageTorpilleur);
        imageView.setFitWidth(64); // Ajustez la largeur selon vos besoins
        menuItem = menuItemTorpilleur;
        menuItem.setVisible(true);
    }

    /**
     * Méthode appelée lors du placement d'un bateau.
     * @param event Événement de clic sur le bouton de placement.
     */
    @FXML
    void placerBateau(ActionEvent event) {
        Button button = (Button) event.getSource();

        int ligne = GridPane.getRowIndex(button);
        int colonne = GridPane.getColumnIndex(button);

        if(bateauHorizontale){
            if((colonne) + longueurBateaux[choixBateau - 1] > 11){
                afficherText.setText("Position non valide.");
                return;
            }
        } else{
            if ((ligne) + longueurBateaux[choixBateau - 1] > 11){
                afficherText.setText("Position non valide.");
                return;
            }
        }

        for(int i = 0 ; i < 10 ; i++){
            for(int x = 0 ; x < 10 ; x++){
                if(grillePlacement[i][x] == choixBateau){
                    afficherText.setText("Ce bateau à déjà été placé.");
                    return;
                }
            }
        }

        if(bateauHorizontale){
            for(int i = 0 ; i < longueurBateaux[choixBateau - 1] ; i++){
                if(grillePlacement[ligne - 1][(colonne - 1) + i] != 0){
                    afficherText.setText("Une des case est déjà occupée.");
                    return;
                }
            }
        } else {
            for(int i = 0 ; i < longueurBateaux[choixBateau - 1] ; i++){
                if(grillePlacement[(ligne - 1) + i][colonne - 1] != 0){
                    afficherText.setText("Une des case est déjà occupée.");
                    return;
                }
            }
        }

        //Placement bateaux
        if(bateauHorizontale){
            for(int i = 0 ; i < longueurBateaux[choixBateau - 1] ; i++){
                grillePlacement[ligne - 1][(colonne - 1) + i] = choixBateau;
            }

        } else {
            for(int i = 0 ; i < longueurBateaux[choixBateau - 1] ; i++){
                grillePlacement[(ligne - 1) + i][colonne - 1] = choixBateau;
            }
        }

        afficherText.setText("Le bateau va être placé.");

        ImageView bateau = new ImageView(imageView.getImage());
        bateau.setFitWidth(imageView.getFitWidth());
        bateau.setFitHeight(30);

        if (!bateauHorizontale) {
            bateau.setRotate(90); // Rotation de 90 degrés pour l'orientation verticale

            switch (choixBateau){
                case 1 :
                    bateau.setTranslateX(bateau.getTranslateX()-17); // Modification de la position en X
                    bateau.setTranslateY(bateau.getTranslateY()+15); // Modification de la position en Y
                    break;

                case 2 :
                    bateau.setTranslateX(bateau.getTranslateX()-32);
                    bateau.setTranslateY(bateau.getTranslateY()+27);
                    break;
                case 3 :
                    bateau.setTranslateX(bateau.getTranslateX()-29);
                    bateau.setTranslateY(bateau.getTranslateY()+28);
                    break;
                case 4 :
                    bateau.setTranslateX(bateau.getTranslateX()-48);
                    bateau.setTranslateY(bateau.getTranslateY()+48);
                    break;
                case 5 :
                    bateau.setTranslateX(bateau.getTranslateX()-62);
                    bateau.setTranslateY(bateau.getTranslateY()+64);
                    break;
            }

        } else {
            bateau.setRotate(0); // Pas de rotation pour l'orientation horizontale
        }

        // Placer le bateau dans la grille aux coordonnées spécifiées
        gridPane.add(bateau, colonne, ligne);
        compteurBateaux++;
        menuItem.setVisible(false);

        if(compteurBateaux > 4){
            for (int i = 0 ; i < 10 ; i++){
                System.arraycopy(grillePlacement[i], 0, envoyerGrillePlacement[i], 0, 10);
            }
        }
    }

    /**
     * Méthode appelée lors de la sélection de l'orientation du bateau.
     * @param event Événement de sélection de l'orientation.
     */
    @FXML
    void selectionOrientation(ActionEvent event) {
        MenuItem menuItem = (MenuItem) event.getSource();
        String orientationSelectionnee = menuItem.getText();

        // Appliquer la rotation en fonction de l'orientation sélectionnée
        if (orientationSelectionnee.equals("Horizontale")) {
            bateauHorizontale = true;
            imageView.getTransforms().clear(); // Effacer les transformations précédentes
            imageView.getTransforms().add(rotation); // Applique la rotation
            rotation.setAngle(0); // Aucune rotation
        } else if (orientationSelectionnee.equals("Verticale")) {
            bateauHorizontale = false;
            imageView.getTransforms().clear();
            imageView.getTransforms().add(rotation);
            rotation.setAngle(90); // Rotation de 90 degrés pour l'orientation verticale
        }
    }

    /**
     * Méthode appelée lors de la sélection du type de bateau.
     * @param event Événement de sélection du type de bateau.
     */
    @FXML
    void selectionBateaux(ActionEvent event) {
        menuItem = (MenuItem) event.getSource();
        String bateauSelectionne = menuItem.getText();
        imageView.setFitHeight(30); // Ajustement de la hauteur

        switch (bateauSelectionne) {
            case "Torpilleur":
                choixBateau = 1;
                imageView.setImage(imageTorpilleur); // imageView affiche l'image du Torpilleur
                imageView.setFitWidth(64);  // Ajuster la largeur
                break;
            case "Sous-marin":
                choixBateau = 2;
                imageView.setImage(imageSousMarin);
                imageView.setFitWidth(96);
                break;
            case "Contre-torpilleur":
                choixBateau = 3;
                imageView.setImage(imageContreTorpilleur);
                imageView.setFitWidth(96);
                break;
            case "Croiseur":
                choixBateau = 4;
                imageView.setImage(imageCroiseur);
                imageView.setFitWidth(128);
                break;
            case "Porte-avions":
                choixBateau = 5;
                imageView.setImage(imagePorteAvions);
                imageView.setFitWidth(160);
                break;
            default:
                break;
        }
    }

    /**
     * Méthode appelée pour aller au jeu une fois tous les bateaux placés.
     * @throws IOException Si une erreur survient lors du changement de scène vers EcranDuJeu.
     */
    @FXML
    void allerAuJeu() throws IOException {
        if(compteurBateaux > 4){
            HelloApplication.changerScene("EcranDuJeu");
        }
    }

}
